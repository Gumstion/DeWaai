<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4  col-md-4 col-sm-4">
                <div class="footer_dv">
                    <h4>Pagina's</h4>
                    <ul>
                        <li class="line_rv"><a href="../index.php">Home</a></li>
                        <li><a href="../cursussen.php">Cursussen</a></li>
                        <li><a href="../login.php">Login</a></li>
                        <li><a href="../registreren.php">Registreren</a></li>
                        <li><a href="#">Item</a></li>
                        <li><a href="../contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4  col-md-4 col-sm-4">
                <div class="footer_dv">
                    <h4>Cursussen</h4>
                    <ul>
                        <li><a href="../cursussen.php">Cursussen</a></li>
                        <li><a href="#">Item</a></li>
                        <li><a href="#">Item</a></li>
                        <li><a href="#">Item</a></li>


                    </ul>
                </div>
            </div>
            <div class="col-lg-4  col-md-4 col-sm-4">
                <div class="footer_dv">
                    <h4>Contactgegevens</h4>
                    <p>Heeg, Friesland</p>
                    <p>Stationslaan 45a</p>
                    <p>0652658942<br>


                    </p></div>
            </div>
        </div>
    </div>
</section>

</body>

</html>