<?php
include 'includes/header.php';

$db->getAllSchepen();
?>

<?php
include 'includes/footer.php';
?>

