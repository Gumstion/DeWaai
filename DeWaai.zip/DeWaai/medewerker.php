<?php
include 'includes/header.php';

$db->getAllMedewerkers();
?>

<?php
include 'includes/footer.php';
?>

