<?php
include 'includes/header.php';

$db->getAllCursus();
?>

<?php
include 'includes/footer.php';
?>

